const check = document.getElementById("enabledCheck");
const status = document.getElementById("status");

chrome.storage.local.get(["enabled"], ({ enabled }) => {
  check.checked = enabled !== false; // 기본값 true
  render();
});

check.addEventListener("change", () => {
  chrome.storage.local.set({ enabled: check.checked }, render);
});

function render() {
  status.textContent = check.checked
    ? "켜짐: 타이머 알람이 울리면 다른 탭 영상이 자동으로 멈춥니다."
    : "꺼짐: 자동 정지 기능이 비활성화되었습니다.";
}
